//  Functions Assignment Exercise B

//  main.cpp
//
//  Created by 137368 - Victor Mwendwa on 12/1/21.
//
#include <iostream>
using namespace std;

int main(){
    
   int array[7];
   int n = 7, sum = 0;
   int i = 0;
   int count = 0;
   float markAverage;
   
       cout<<" Student Marks Average Program \n\n";
    cout<<" Input seven student marks : \n";
    cout<<"\n";
    
    //A For Loop used to store values inputted within the array.
    for(i = 0; i < n; ++i){
       cout << "Input Student Mark " << i + 1 << " : ";
       cin >> array[i];
    }
    
    // A For Loop used to sum marks inputted.
     for(int i = 0; i<n ; i++){
      sum+=array[i];
   }
    
    markAverage = sum / n;
    cout<<"\n";
    cout << " Average For Seven Marks Is > " << markAverage;
 
    return 0;
}

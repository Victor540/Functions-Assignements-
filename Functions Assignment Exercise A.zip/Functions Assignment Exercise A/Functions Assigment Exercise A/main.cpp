//  Functions Assigment Exercise A
//
//  Main.cpp
//
//  Created by 137368 Victor Mwendwa on 12/1/21.
//
#include <iostream>
using namespace std;
//
//The Function Prototype for Check Even
double checkEven(int a);

//The Function Declaration for Check Even
double checkEven(int a){
    double result;
    result = a%2;
    return result;
}

int main(){
    double a;
    bool r;
    char response;
    do{
        cout<<" Check Even Calculator Function \n"<<endl;
        cout<<" Input any number : \n\n";
        cin>>a;
        cout<<"\n";
        r = checkEven(a);
        if(r == 0){
        cout<<" Number "<<a<<" is Even \n";
        cout<<" Try Another Number ? (Y/N)";
        cout<<"\n";
        cin>>response;
        }else{
        cout<<" Number "<<a<<" is Not Even \n";
        cout<<" Try Another Number ? (Y/N)";
        cout<<"\n";
        cin>>response;
        }
    }while(response=='Y');
    return 0;
}
